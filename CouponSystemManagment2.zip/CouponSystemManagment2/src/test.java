import com.coupons.sys.clients.AdminFacade;
import com.coupons.sys.clients.ClientType;
import com.coupons.sys.clients.CompanyFacade;
import com.coupons.sys.clients.CustomerFacade;
import com.coupons.sys.clients.LoginManager;
import com.coupons.sys.db.CouponDAO;
import com.coupons.sys.db.CouponDBDAO;
import com.coupons.sys.exeptions.CouponsSystemException;

public class test {

	public static void main(String[] args) throws CouponsSystemException {
		// TODO Auto-generated method stub

		
		AdminFacade admin=new AdminFacade();
	System.out.println(	admin.getPassword());
	System.out.println(admin.getEmail());
	System.out.println(admin.getAllCustomers());
	CouponDAO dao=new CouponDBDAO();
System.out.println("all copupons:"+	dao.getAllCoupons());
	try {
		CompanyFacade company=(CompanyFacade) LoginManager.getInstance().logIn("BBB@bbb.com", "3b56", ClientType.COMPANY);
		System.out.println(company.getCompanyCoupons());
		CustomerFacade customer=(CustomerFacade)LoginManager.getInstance().logIn("shir@gmail.com","2345",ClientType.CUSTOMER);
		System.out.println(customer.getCustomer());
		System.out.println(customer.getAllCustomerCoupons());
	} catch (CouponsSystemException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		
	}

}
