package coupon.system.bean;

import java.sql.Date;

public class Income {
	private int id;
	private String name;
	private Date date;
	private IncomeType description;
	private double amount;
	private int clientId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}

	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public Income() {
		super();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Income other = (Income) obj;
		if (id != other.id)
			return false;
		return true;
	}
	public Income(String name, Date date, IncomeType description, double amount, int clientId) {
		super();
		this.name = name;
		this.date = date;
		this.description = description;
		this.amount = amount;
		this.clientId = clientId;
	}
	public Income(int id, String name, Date date, IncomeType description, double amount, int clientId) {
		super();
		this.id = id;
		this.name = name;
		this.date = date;
		this.description = description;
		this.amount = amount;
		this.clientId = clientId;
	}
	public IncomeType getDescription() {
		return description;
	}
	public void setDescription(IncomeType description) {
		this.description = description;
	}
	

}
