package coupon.system.bean;

public enum IncomeType {
	Customer_Purchase("the customer purchased a coupon"), Company_New_Coupon("the company add a new coupon"),
	Company_Upadate_Coupon("the company updated a coupon ");

	private String description;

	private IncomeType(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

}
