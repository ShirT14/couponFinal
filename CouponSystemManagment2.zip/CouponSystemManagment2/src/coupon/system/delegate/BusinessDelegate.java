package coupon.system.delegate;

import java.util.Collection;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import coupon.system.bean.Income;
import coupon.system.bean.IncomeType;

public class BusinessDelegate {
	private Client client = ClientBuilder.newClient();
	private WebTarget webTarget = client.target("http://localhost:8888/api");

	public synchronized Income storeIncome(Income income) {

		Response response = webTarget.path("income").request().put(Entity.json(income));
    
		System.out.println(Entity.json(income));
		if (response.getStatusInfo() == Response.Status.OK) {
			return response.readEntity(Income.class);
		} else {
			int statusCode = response.getStatus();
			String reason = response.getStatusInfo().getReasonPhrase();
			throw new RuntimeException("Store income " + income + " failed: " + statusCode + ": " + reason);
		}
	}

	public synchronized Collection<Income>  incomeByCompany(int id) {
		
		Response response = webTarget.path("company-incomes/" +id).request().get();
		System.out.println(webTarget.getUri());
		if (response.getStatusInfo()== Response.Status.OK) {
			return response.readEntity(new GenericType<Collection<Income>>() {
			});
		} else {
			int statusCode = response.getStatus();
			String reason = response.getStatusInfo().getReasonPhrase();
			throw new RuntimeException("income by company id " + id + " failed: " + statusCode + ": " + reason);
		}
	}

	public synchronized Collection<Income> incomeByCustomer(int id) {
		Response response = webTarget.path("customer-incomes/" + id).request().get();
		if (response.getStatusInfo() == Response.Status.OK) {
			return response.readEntity(new GenericType<Collection<Income>>() {
			});
		} else {
			int statusCode = response.getStatus();
			String reason = response.getStatusInfo().getReasonPhrase();
			throw new RuntimeException("income by customer id " + id + " failed: " + statusCode + ": " + reason);
		}
	}

	public synchronized Collection<Income> allIncomes() {
		Response response = webTarget.path("all-incomes").request().get();
		if (response.getStatusInfo() == Response.Status.OK) {
			return response.readEntity(new GenericType<Collection<Income>>() {
			});
		} else {
			int statusCode = response.getStatus();
			String reason = response.getStatusInfo().getReasonPhrase();
			throw new RuntimeException("all incomes failed: " + statusCode + ": " + reason);
		}
	}
	

}
