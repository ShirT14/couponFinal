package coupon.system.delegate;

import java.util.Collection;

import coupon.system.bean.Income;
import coupon.system.bean.IncomeType;

public class Test {
public static void main(String[] args) {
		
		BusinessDelegate bs=new BusinessDelegate();
		java.util.Date utilDate=new java.util.Date();
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
	
		Income income=new Income("purchase income",sqlDate , IncomeType.Customer_Purchase, 100, 9);
	
		Income income2=	bs.storeIncome(income);
//		System.out.println(bs.incomeByCompany(14));
	Collection<Income> incomes=bs.allIncomes();
	System.out.println(incomes);
//		Collection<Income> incomes=bs.allIncomes();
		
		//		System.out.println(bs.incomeByCustomer(9));
	}
}
