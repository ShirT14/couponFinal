package coupon.system.ws;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.coupons.sys.beans.Coupon;
import com.coupons.sys.clients.CompanyFacade;
import com.coupons.sys.clients.CustomerFacade;
import com.coupons.sys.exeptions.CouponsSystemException;

import coupon.system.bean.Income;
import coupon.system.bean.IncomeType;
import coupon.system.delegate.BusinessDelegate;

import java.sql.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;


@Path("sec/customer-service")

@Consumes(MediaType.APPLICATION_JSON)

@Produces(MediaType.APPLICATION_JSON)
public class CustomerService {
@Context HttpServletRequest req;
 
private BusinessDelegate bs=new BusinessDelegate();


private HttpSession session;
@PostConstruct
public void setSession()
{
	session=req.getSession(false);
	System.out.println(req);

	
	
}

	@Path("get-customer")
	@GET
	public Response getCustomer()  {
		
		try {
			CustomerFacade customer=(CustomerFacade)session.getAttribute("clientFacade");
			
			return Response.status(Response.Status.OK).entity(customer.getCustomer()).build();
		} catch (CouponsSystemException e) {
			
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("get-all-coupons-by-max-price")
	@GET
	public Response getAllCouponsByMaxPrice(@QueryParam ("maxPrice") Double maxPrice)  {
		try {
			CustomerFacade customer=(CustomerFacade)session.getAttribute("clientFacade");
			return  Response.status(Response.Status.OK).entity(customer.getAllCoupon(maxPrice)).build();
		} catch (CouponsSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return  Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}

	}
	@Path("get-all-coupons-by-category")
	@GET
	public Response getAllCouponsByMaxPrice(@QueryParam ("categoryId") int categoryId)  {
		try {
			CustomerFacade customer=(CustomerFacade)session.getAttribute("clientFacade");
			return  Response.status(Response.Status.OK).entity(customer.getAllCustomerCoupons(categoryId)).build();
		} catch (CouponsSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return  Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}

	}

	@Path("get-all-customer-coupons")
	@GET
	public Response getAllCustomerCoupons() {
		 try {
			 CustomerFacade customer=(CustomerFacade)session.getAttribute("clientFacade");
			return  Response.status(Response.Status.OK).entity(customer.getAllCustomerCoupons()).build();
		} catch (CouponsSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return  Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}

	}

	@Path("purchase-coupon")
	@POST
	
	public Response purchaseCoupon( Coupon coupon) {
		
		try {
			CustomerFacade customer=(CustomerFacade)session.getAttribute("clientFacade");
			customer.purchaseCoupon(coupon);
			java.util.Date utilDate=new java.util.Date();
			java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		
			Income income=new Income("purchase income from the customer: "+customer.getCustomer().getFirstName()+customer.getCustomer().getLastName(),sqlDate , IncomeType.Customer_Purchase, coupon.getPrice(), customer.getCustomer().getId());
		
			Income income2=	bs.storeIncome(income);
	
		
			
		} catch (CouponsSystemException e) {
			String eror=e.getMessage();
			
			return  Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
		catch(RuntimeException e) {
			CouponsSystemException e1=new CouponsSystemException("income didn't aplay");
			
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
			
		}
		return  Response.status(Response.Status.OK).build();
	
		
	}
	@Path("all-coupon-for-sale")
	@GET
	public Response allCouponsForSale()
	{
	try {
		CustomerFacade customer=(CustomerFacade)session.getAttribute("clientFacade");
		List<Coupon> allCoupons=customer.getAllCouponsForSale();
	return	Response.status(Response.Status.OK).entity(allCoupons).build();
		
	} catch (CouponsSystemException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return  Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
	}
	}
	
	@Path("log-out")
	@GET
	public Response logout() {
		try {
               this.session.invalidate();
			return Response.status(Response.Status.OK).build();
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();

		}
	}
	@Path("get-category")
	@GET
	public Response getCategory(@QueryParam("categoryId") int categoryId)
	{
		try {CustomerFacade customer=(CustomerFacade) session.getAttribute("clientFacade");
		return Response.status(Response.Status.OK).entity(customer.getCategoryName(categoryId))
				.build();
	} catch (CouponsSystemException e) {
		e.printStackTrace();
		return Response.status(Response.Status.OK).entity(e.getMessage()).build();
	}
	}
	@Path("get-company")
	@GET
	public Response getCompany( @QueryParam("companyId") int companyId)
	{
		try {CustomerFacade customer=(CustomerFacade) session.getAttribute("clientFacade");
		return Response.status(Response.Status.OK).entity(customer.getCompanyName(companyId))
				.build();
	} catch (CouponsSystemException e) {
		e.printStackTrace();
		return Response.status(Response.Status.OK).entity(e.getMessage()).build();
	}
	}
	
	
}