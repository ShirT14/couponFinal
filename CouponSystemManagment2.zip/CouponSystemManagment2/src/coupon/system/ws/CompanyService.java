package coupon.system.ws;

import java.util.Collection;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.coupons.sys.beans.Coupon;
import com.coupons.sys.clients.ClientFacade;
import com.coupons.sys.clients.ClientType;
import com.coupons.sys.clients.CompanyFacade;
import com.coupons.sys.clients.CustomerFacade;
import com.coupons.sys.clients.LoginManager;
import com.coupons.sys.exeptions.CouponsSystemException;

import coupon.system.bean.Income;
import coupon.system.bean.IncomeType;
import coupon.system.delegate.BusinessDelegate;

@Path("sec/company-service")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class CompanyService {

	@Context
	HttpServletRequest req;
	BusinessDelegate bs=new BusinessDelegate();

	private HttpSession session;
	@PostConstruct
	public void setSession()
	{
		session=req.getSession(false);
		System.out.println(req);

		
		
	}

	@Path("get-company")
	@GET
	public Response getComany() {
		try {
			CompanyFacade company=(CompanyFacade) this.session.getAttribute("clientFacade");
			return Response.status(Response.Status.OK).entity(company.getCompany()).build();

		} catch (Exception e) {

			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("get-coupons")
	@GET
	public Response getCoupons() {
		try {
			System.out.println(req);
			CompanyFacade company=(CompanyFacade) this.session.getAttribute("clientFacade");
			List<Coupon> allCoupons = company.getCompanyCoupons();
			return Response.status(Response.Status.OK).entity(allCoupons).build();
		} catch (CouponsSystemException e) {
			e.printStackTrace();

			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("coupon-by-max-price")
	@GET
	public Response getCouponsByMaxPrice(@QueryParam("maxPrice") Double maxPrice) {

		try {
			CompanyFacade company=(CompanyFacade) session.getAttribute("clientFacade");
			return Response.status(Response.Status.OK).entity(company.getCompanyCoupons(maxPrice))
					.build();
		} catch (CouponsSystemException e) {

			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("get-coupon-by-category")
	@GET
	public Response GetCouponsByCategory(@QueryParam("categoryId") int categoryId) {
		try {CompanyFacade company=(CompanyFacade) session.getAttribute("clientFacade");
			return Response.status(Response.Status.OK).entity(company.getCompanyCoupons(categoryId))
					.build();
		} catch (CouponsSystemException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("add-coupon")
	@POST
	public Response addCoupon(Coupon coupon) {
		try {
			CompanyFacade company=(CompanyFacade) session.getAttribute("clientFacade");
			company.addCoupon(coupon);
			
			java.util.Date utilDate=new java.util.Date();
			java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		
			Income income=new Income("new coupon income from the company: "+company.getCompany().getName(),sqlDate , IncomeType.Company_New_Coupon, 100, company.getCompany().getId());
		try {
			Income income2=	bs.storeIncome(income);
		}
		catch (RuntimeException e)
		{
			return  Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();	
		}
			return Response.status(Response.Status.OK).build();
		} catch (CouponsSystemException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("update-coupon")
	@PUT
	public Response updateCoupon(Coupon coupon) {
		try {
			CompanyFacade company=(CompanyFacade) session.getAttribute("clientFacade");
			company.updateCoupon(coupon);
			java.util.Date utilDate=new java.util.Date();
			java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		
			Income income=new Income("coupon update income from the company: "+company.getCompany().getName(),sqlDate , IncomeType.Company_Upadate_Coupon, coupon.getPrice(), company.getCompany().getId());
		try {
			Income income2=	bs.storeIncome(income);
		}
		catch (RuntimeException e)
		{
			return  Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();	
		}
			return Response.status(Response.Status.OK).build();
		} catch (CouponsSystemException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();

		}
	}

	@Path("delete-coupon")
	@DELETE
	public Response deleteCoupon(@QueryParam("couponId") int couponId) {
		try {
			CompanyFacade company=(CompanyFacade) session.getAttribute("clientFacade");
			company.deleteCoupon(couponId);
			return Response.status(Response.Status.OK).build();
		} catch (CouponsSystemException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("log-out")
	@GET
	public Response logout() {
		try {
               this.session.invalidate();
			return Response.status(Response.Status.OK).build();
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();

		}
	}
	@Path("get-category")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	 
	
	public Response getCategory(@QueryParam("categoryId") int categoryId)
	{
		try {
			CompanyFacade company=(CompanyFacade)this.session.getAttribute("clientFacade");
			System.out.println(company.getCategoryName(categoryId));
		return Response.status(Response.Status.OK).entity(company.getCategoryName(categoryId))
				.build();
	} catch (CouponsSystemException e) {
		e.printStackTrace();
		return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
	}
	}
	@Path("company-incomes")
	@GET
	public Response getAllCompanyIncomes() {
		try {
			CompanyFacade company=(CompanyFacade)this.session.getAttribute("clientFacade");
			Collection<Income>allIncomes=bs.incomeByCompany(company.getCompany().getId());
			return Response.status(Response.Status.OK).entity(allIncomes).build();
			
		}
		catch (Exception e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
		
	}

}