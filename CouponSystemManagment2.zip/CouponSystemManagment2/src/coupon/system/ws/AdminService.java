package coupon.system.ws;

import java.util.Collection;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import org.glassfish.jersey.media.multipart.FormDataParam;
import com.coupons.sys.beans.Company;
import com.coupons.sys.beans.Customer;
import com.coupons.sys.clients.AdminFacade;
import com.coupons.sys.clients.ClientFacade;
import com.coupons.sys.clients.ClientType;
import com.coupons.sys.clients.CompanyFacade;
import com.coupons.sys.clients.CustomerFacade;
import com.coupons.sys.clients.LoginManager;
import com.coupons.sys.exeptions.CouponsSystemException;

import coupon.system.bean.Income;
import coupon.system.delegate.BusinessDelegate;

@Path("sec/Admin-service")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class AdminService {
	@Context
	HttpServletRequest req;
	HttpSession session;
	BusinessDelegate bs=new BusinessDelegate();
	CouponsSystemException disConnected=new CouponsSystemException("you are disconnected, please logout and login again,make sure that your details are currect");
	@PostConstruct
	public void setSession()
	{
		this.session=req.getSession(false);
		
		
		
	}
//	private AdminFacade adminFacade = (AdminFacade)session.getAttribute("clientFacade");

	@Path("add-company")
	@POST
	public Response addCompany(Company company) {
		try {
			AdminFacade admin=(AdminFacade) this.session.getAttribute("clientFacade");
			if(admin==null)
			{
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(disConnected.getMessage()).build();
			}
		admin.addCompany(company);
			return Response.status(Response.Status.OK).build();
		} catch (CouponsSystemException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("delete-company")
	@DELETE
	public Response deleteCompany(@QueryParam("companyId") int companyId) {
		try {
			AdminFacade admin=(AdminFacade) this.session.getAttribute("clientFacade");
			if(admin==null)
			{
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(disConnected.getMessage()).build();
			}
			admin.deleteCompany(companyId);
			return Response.status(Response.Status.OK).build();
		} catch (CouponsSystemException e) {

			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("add-customer")
	@POST
	public Response addCustomer(Customer customer) {
		try {
			AdminFacade admin=(AdminFacade) this.session.getAttribute("clientFacade");
			if(admin==null)
			{
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(disConnected.getMessage()).build();
			}
			admin.addCustomer(customer);
			return Response.status(Response.Status.OK).build();
		} catch (CouponsSystemException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("deleteCustomer")
	@DELETE
	public Response deleteCustomer(@QueryParam("customerId") int customerId) {
		try {
			AdminFacade admin=(AdminFacade) this.session.getAttribute("clientFacade");
			if(admin==null)
			{
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(disConnected.getMessage()).build();
			}
			
			admin.deleteCustomer(customerId);
			return Response.status(Response.Status.OK).build();

		} catch (CouponsSystemException e) {

			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}

	}

	@Path("get-all-companies")
	@GET
	public Response getAllCompanies() {
		try {
			AdminFacade admin=(AdminFacade) this.session.getAttribute("clientFacade");
			if(admin==null)
			{
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(disConnected.getMessage()).build();
			}
			else {
			List<Company> allCompanies =admin.getAllCompanies();
			return Response.status(Response.Status.OK).entity(allCompanies)
					.build();
			}
		} catch (CouponsSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("get-all-customers")
	@GET
	public Response getAllCustomer() {
		try {
			AdminFacade admin=(AdminFacade)this.session.getAttribute("clientFacade");
			if(admin==null)
			{
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(disConnected.getMessage()).build();
			}
			List<Customer>allCustomers=admin.getAllCustomers();
			return Response.status(Response.Status.OK).entity(allCustomers)
					.build();
		} catch (CouponsSystemException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();

		}
	}

	@Path("get-customer")
	@GET
	public Response getCustomer(@QueryParam("customerId") int customerId) {
		try {
			AdminFacade admin=(AdminFacade) this.session.getAttribute("clientFacade");
			if(admin==null)
			{
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(disConnected.getMessage()).build();
			}
			Customer customer=admin.getOneCustomer(customerId);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(customer)
					.build();
		} catch (CouponsSystemException e) {

			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}

	@Path("get-company")
	@GET
	public Response getCompany(@QueryParam("companyId") int companyId) {
		try {
			AdminFacade admin=(AdminFacade) this.session.getAttribute("clientFacade");
			if(admin==null)
			{
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(disConnected.getMessage()).build();
			}
			Company company=admin.getComapny(companyId);
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(company)
					.build();
		} catch (CouponsSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}

	}

	@Path("update-company")
	@PUT
	public Response updateCompany(Company company) {
		try {
			AdminFacade admin=(AdminFacade) this.session.getAttribute("clientFacade");
			if(admin==null)
			{
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(disConnected.getMessage()).build();
			}
			admin.updateCompany(company);
			return Response.status(Response.Status.OK).build();
		} 
		catch (CouponsSystemException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}

	}

	@Path("update-customer")
	@PUT
	public Response updateCustomer(Customer customer) {
		try {
			AdminFacade admin=(AdminFacade) this.session.getAttribute("clientFacade");
			if(admin==null)
			{
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(disConnected.getMessage()).build();
			}
			admin.updateCustomer(customer);
			return Response.status(Response.Status.OK).build();
		} catch (CouponsSystemException e) {

			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}

	}

	
	@Path("log-out")
	@GET
	public Response logout() {
		try {
               this.session.invalidate();
			return Response.status(Response.Status.OK).build();
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();

		}
	}
	@Path("incomes")
	@GET
	public Response alIncomes() {
		try {
			AdminFacade company=(AdminFacade)this.session.getAttribute("clientFacade");
			
			Collection<Income>allIncomes=bs.allIncomes(); 
			return Response.status(Response.Status.OK).entity(allIncomes).build();
			
		}
		catch (Exception e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
		
	}
	@Path("customer-incomes")
	@GET
	public Response allIncomesByCustomer(@QueryParam("id") int id) {
		try {
			AdminFacade admin=(AdminFacade)this.session.getAttribute("clientFacade");
			Collection<Income>allIncomes=bs.incomeByCustomer(id); 
			return Response.status(Response.Status.OK).entity(allIncomes).build();
			
		}
		catch (Exception e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
		
	}
	@Path("company-incomes")
	@GET
	public Response allIncomesByCompany(@QueryParam("id") int id) {
		try {
			AdminFacade admin=(AdminFacade)this.session.getAttribute("clientFacade");
			Collection<Income>allIncomes=bs.incomeByCompany(id); 
			return Response.status(Response.Status.OK).entity(allIncomes).build();
			
		}
		catch (Exception e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
		
	}
}
