package com.shir.Coupons.repository;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shir.Coupons.entities.Income;
@Service
public class IncomeCostumeImpl implements IncomeService {
	@Autowired
	private IncomeRepository incomeRepository;

	@Override
	public void storeIncome(Income income) {

		this.incomeRepository.save(income);
	}

	@Override
	public Collection<Income> viewAllIncome() {

		return incomeRepository.findAll();
	}

	@Override
	public Collection<Income> viewInComeByCustomer(int clientId) {
		return incomeRepository.viewIncomeByCustomer(clientId);
	}

	@Override
	public Collection<Income> viewInComeByCompany(int clientId) {

		return this.incomeRepository.viewAllIncomeByCompany(clientId);
	}

}
