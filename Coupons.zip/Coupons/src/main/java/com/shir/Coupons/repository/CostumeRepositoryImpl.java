package com.shir.Coupons.repository;

import java.util.Collection;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.shir.Coupons.entities.Income;

@Repository 
public class CostumeRepositoryImpl implements CostumeRepository {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Collection<Income> viewIncomeByCustomer(int clientId) {
		String JpQL=" From Income WHERE client_Id= "+ clientId+" AND (description =  "+ com.shir.Coupons.entities.IncomeType.Customer_Purchase.ordinal()+")";
		TypedQuery<Income> query=entityManager.createQuery(JpQL,Income.class);
		Collection<Income> result=query.getResultList();
		return result;
	}

	@Override
	public Collection<Income> viewAllIncomeByCompany(int clientId) {
		String JpQL="FROM Income WHERE client_Id= "+ clientId +" AND (description = "+ com.shir.Coupons.entities.IncomeType.Company_New_Coupon.ordinal()+"OR description="+com.shir.Coupons.entities.IncomeType.Company_Upadate_Coupon.ordinal()+")";
		TypedQuery<Income> query=entityManager.createQuery(JpQL,Income.class);
		Collection<Income> result=query.getResultList();
		return result;
	}

}
