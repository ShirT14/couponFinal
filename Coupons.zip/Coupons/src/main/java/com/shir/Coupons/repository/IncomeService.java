package com.shir.Coupons.repository;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shir.Coupons.entities.Income;



public interface IncomeService {
	
	public void storeIncome(Income income);
	
	public Collection<Income> viewAllIncome();
	

	public Collection<Income>viewInComeByCustomer(int clientId);


	
	public Collection<Income>viewInComeByCompany(int clientId);



}
