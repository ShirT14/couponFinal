package com.shir.Coupons.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shir.Coupons.entities.Income;

@Transactional
public interface IncomeRepository extends JpaRepository<Income, Integer>, CostumeRepository {

}
