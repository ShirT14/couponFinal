package com.shir.Coupons.repository;

import java.util.Collection;

import org.springframework.stereotype.Repository;

import com.shir.Coupons.entities.Income;

@Repository
public interface CostumeRepository {
	
	public Collection <Income>	viewIncomeByCustomer(int clientId);

	public Collection<Income> viewAllIncomeByCompany(int clientId);

}
