import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Coupon } from '../models/Coupon';
import { Observable } from 'rxjs';
import { Customer } from '../models/Customer';

@Injectable({
  providedIn: 'root'
})
export class CustomersService {

  constructor( private http:HttpClient) { }

  
  getAllCoupons():Observable<Coupon[]>
{
  return this.http.get<Coupon[]>("http://localhost:8080/CouponSystemManagment/rest/sec/customer-service/all-coupon-for-sale",{withCredentials:true});
   
}
  
  getAllCustomerCoupons():Observable<Coupon[]>
{
  return this.http.get<Coupon[]>('http://localhost:8080/CouponSystemManagment/rest/sec/customer-service/get-all-customer-coupons',{withCredentials:true});
   
}
  getAllCouponsByCategory(categoryId:number):Observable<Coupon[]>
{
  
  const url = `${'http://localhost:8080/CouponSystemManagment/rest/sec/customer-service/get-all-coupons-by-category'}?categoryId=${categoryId}`
  return this.http.get<Coupon[]>(url,{withCredentials:true});
   
}
  getAllCouponsByMaxPrice(maxPrice:number):Observable<Coupon[]>
{
  
   const url = `${'http://localhost:8080/CouponSystemManagment/rest/sec/customer-service/get-all-coupons-by-max-price'}?maxPrice=${maxPrice}`
  return this.http.get<Coupon[]>(url,{withCredentials:true});
   
}

getCustomer():Observable<Customer>
{
  return this.http.get('http://localhost:8080/CouponSystemManagment/rest/sec/customer-service/get-customer',{withCredentials:true});
}

purchaseCoupon(coupon:Coupon)
{
  
  return this.http.post('http://localhost:8080/CouponSystemManagment/rest/sec/customer-service/purchase-coupon',coupon,{withCredentials:true});
}
getCategoryName(id:number):Observable<String>
{
  const url = `${'http://localhost:8080/CouponSystemManagment/rest/sec/customer-service/get-category'}?categoryId=${id}`;
  return this.http.get<String>(url,{withCredentials:true});
}
getCompanyName(id:number):Observable<string>
{
  const url = `${'http://localhost:8080/CouponSystemManagment/rest/sec/customer-service/get-company'}?companyId=${id}`;
  return this.http.get<string>(url,{withCredentials:true});
}
logout()

{
  return this.http.get("http://localhost:8080/CouponSystemManagment/rest/sec/customer-service/log-out",{withCredentials:true});
}
}


