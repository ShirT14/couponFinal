import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/User';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http:HttpClient) { }

  login(email:string,password:string,clientType:string)
  {
    const url=`${'http://localhost:8080/CouponSystemManagment/rest/login-service/login'}?email=${email}&password=${password}&client-type=${clientType}`;
  
  return this.http.get(url,{withCredentials:true});
  }
}
