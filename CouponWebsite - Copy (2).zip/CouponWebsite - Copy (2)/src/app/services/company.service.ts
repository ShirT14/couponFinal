import { Injectable } from '@angular/core';

import { Coupon } from '../models/Coupon';
import { Observable, observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Company } from '../models/Company';
import { Income } from '../models/Income';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  constructor(private http:HttpClient) { }

  getAllCoupons():Observable<Coupon[]>
{
  return this.http.get<Coupon[]>("http://localhost:8080/CouponSystemManagment/rest/sec/company-service/get-coupons",{withCredentials:true});
   
}
  getAllCouponsByCategory(categoryId:number):Observable<Coupon[]>
{

   const url = `${'http://localhost:8080/CouponSystemManagment/rest/sec/company-service/get-coupon-by-category'}?categoryId=${categoryId}`
  return this.http.get<Coupon[]>(url,{withCredentials:true});
   
}
  getAllCouponsByMaxPrice(maxPrice:number):Observable<Coupon[]>
{
  alert("from max price")
    const url = `${'http://localhost:8080/CouponSystemManagment/rest/sec/company-service/coupon-by-max-price'}?maxPrice=${maxPrice}`
  return this.http.get<Coupon[]>(url,{withCredentials:true});
   
}
updateCoupon(coupon:Coupon)
{
  return this.http.put('http://localhost:8080/CouponSystemManagment/rest/sec/company-service/update-coupon',coupon,{withCredentials:true});
}
getCompany():Observable<Company>
{
  return this.http.get('http://localhost:8080/CouponSystemManagment/rest/sec/company-service/get-company',{withCredentials:true});
}
addCoupon(coupon:Coupon)
{
  return this.http.post('http://localhost:8080/CouponSystemManagment/rest/sec/company-service/add-coupon',coupon,{withCredentials:true});
}
deleteCoupon(id:number)
{
  const url = `${'http://localhost:8080/CouponSystemManagment/rest/sec/company-service/delete-coupon'}?couponId=${id}`;
  return this.http.delete(url,{withCredentials:true});
}
getCategoryName(id:number):Observable<string>
{
  const url = `${'http://localhost:8080/CouponSystemManagment/rest/sec/company-service/get-category?categoryId='}${id}`;
  return this.http.get(url,{responseType: 'text'});
}
logout()
{
  return this.http.get(" http://localhost:8080/CouponSystemManagment/rest/sec/company-service/log-out");
}
incomes():Observable<Income[]>
{
  
  return this.http.get<Income[]>('http://localhost:8080/CouponSystemManagment/rest/sec/company-service/company-incomes');
}
}
