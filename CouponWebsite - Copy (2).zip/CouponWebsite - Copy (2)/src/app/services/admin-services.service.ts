import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../models/Customer';
import { Company } from '../models/Company';
import { Observable } from 'rxjs';
import { Income } from '../models/Income';

@Injectable({
  providedIn: 'root'
})
export class AdminServicesService {

  constructor(private http:HttpClient) { }
addCustomer(customer:Customer)
{
  return this.http.post('http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/add-customer',customer,{withCredentials:true});
}

addCompany(company:Company)
{
  return this.http.post('http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/add-company',company,{withCredentials:true});
}
updatComapny(company:Company)
{
  return this.http.put("http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/update-company",company,{withCredentials:true});
}
updateCustomer(customer:Customer)
{
  return this.http.put('http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/update-customer',customer,{withCredentials:true});
}
getAllCustomers():Observable<Customer[]>
{

  return this.http.get<Customer[]>('http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/get-all-customers',{withCredentials:true});
  
}
getCustomer(id:number):Observable<Customer>
{

  return this.http.get<Customer>('assets/json/customer.json');
  
}
getAllCompanies():Observable<Company[]>
{
  return this.http.get<Company[]>("http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/get-all-companies",{withCredentials:true});
}
deleteCustomer(id:number)
{
  const url = `${'http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/deleteCustomer'}?customerId=${id}`;
  return this.http.delete(url,{withCredentials:true});
}
deleteCompany(id:number)
{
  const url = `${'http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/delete-company'}?companyId=${id}`;
  return this.http.delete(url,{withCredentials:true});
}
logout()

{
  return this.http.get('http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/log-out',{withCredentials:true});
}
incomes():Observable<Income[]>
{
  return this.http.get<Income[]>('http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/incomes',{withCredentials:true});
}
customerIncome(id:number):Observable<Income[]>
{
  const url=`${'http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/customer-incomes?id='}${id}`;
  return this.http.get<Income[]>(url,{withCredentials:true});
}
companyIncome(id:number):Observable<Income[]>
{
  const url='http://localhost:8080/CouponSystemManagment/rest/sec/Admin-service/company-incomes?id='+id;
  return this.http.get<Income[]>(url,{withCredentials:true});
}
}
