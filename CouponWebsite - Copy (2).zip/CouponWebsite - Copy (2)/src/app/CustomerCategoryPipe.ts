import { Pipe, PipeTransform } from '@angular/core';

import { CustomersService } from './services/customers.service';

@Pipe({
    name:"getCategoryName",
    pure:true
    
    })
    export class getCustomerCategoryPipe implements PipeTransform
    {
      constructor(private customerServ:CustomersService){}
      transform(categoryId: number,ars:any) {
         
this.customerServ.getCategoryName(categoryId).subscribe(categoryName=>
      { const name=categoryName;
          return name},
      err=>{alert("Eror: "+err.message);
    return "eror";}
      );
         
      }
    
    }