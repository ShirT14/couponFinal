import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllCustomerCouponsComponent } from './all-customer-coupons.component';

describe('AllCustomerCouponsComponent', () => {
  let component: AllCustomerCouponsComponent;
  let fixture: ComponentFixture<AllCustomerCouponsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllCustomerCouponsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllCustomerCouponsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
