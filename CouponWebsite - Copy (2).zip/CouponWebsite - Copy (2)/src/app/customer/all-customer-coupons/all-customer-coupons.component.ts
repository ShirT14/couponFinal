import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/models/Coupon';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomersService } from 'src/app/services/customers.service';

@Component({
  selector: 'app-all-customer-coupons',
  templateUrl: './all-customer-coupons.component.html',
  styleUrls: ['./all-customer-coupons.component.css']
})
export class AllCustomerCouponsComponent implements OnInit {
  public allCoupons: Coupon[];
  public categoryId: number;
  public maxPrice: number;
  public clientForm: FormGroup;

  constructor(private customerServ: CustomersService, private formBuilder: FormBuilder) {
    this.clientForm = this.formBuilder.group({
      price: ['', Validators.pattern["(0-9)"]],
    });
  }

  ngOnInit() {
    this.getAllCustomerCoupons();
  }
  
  selectHandler(event: any) {
    this.categoryId = event.target.value;
    if(this.categoryId==0)
    {
      this.getAllCustomerCoupons();
    }
    else{
    this.getAllCouponsByCategory(this.categoryId);
    }
  }

  getAllCustomerCoupons() {
    this.customerServ.getAllCustomerCoupons().subscribe(coupons => {
      this.allCoupons = coupons;
      console.log(this.allCoupons);
    },
      err => {
        alert("Eror: " + err.error);
      });
  }
  getAllCouponsByCategory(categoryId: number) {
    this.customerServ.getAllCouponsByCategory(categoryId).subscribe(coupons => {
      this.allCoupons = coupons;
      console.log(this.allCoupons);
    },
      err => {
        alert("Eror: " + err.error);
      });

  }
  getAllCouponsByMaxPrice() {
    this.customerServ.getAllCouponsByMaxPrice(this.maxPrice).subscribe(coupons => {
      this.allCoupons = coupons;

    },
      err => {
        alert("Eror: " + err.error);
        
      });

  }

}
