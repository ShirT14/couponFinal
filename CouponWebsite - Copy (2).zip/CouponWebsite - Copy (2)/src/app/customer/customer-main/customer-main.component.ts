import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/models/Customer';
import { CustomersService } from 'src/app/services/customers.service';

@Component({
  selector: 'app-customer-main',
  templateUrl: './customer-main.component.html',
  styleUrls: ['./customer-main.component.css']
})
export class CustomerMainComponent implements OnInit {
customer:Customer;
firstName:string;
lastName:string;
  constructor(private customerServ:CustomersService) { }

  ngOnInit() {
    this.customerServ.getCustomer().subscribe(customer=>
      {this.customer=customer;
        this.firstName=customer.firstName;
        this.lastName=customer.lastName;

    },err=>{alert("Error: "+err.error);}
      )
  }

}
