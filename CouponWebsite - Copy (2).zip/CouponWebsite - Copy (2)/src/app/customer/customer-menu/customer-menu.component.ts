import { Component, OnInit } from '@angular/core';
import { CustomersService } from 'src/app/services/customers.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-menu',
  templateUrl: './customer-menu.component.html',
  styleUrls: ['./customer-menu.component.css']
})
export class CustomerMenuComponent implements OnInit {

  constructor(private customerServ:CustomersService , private router:Router) { }

  ngOnInit() {
  }
  logout()
  {
    this.customerServ.logout().subscribe(date=>{
      alert("You arelogged out!");
      this.router.navigate(["/"]);
    })
  }

}
