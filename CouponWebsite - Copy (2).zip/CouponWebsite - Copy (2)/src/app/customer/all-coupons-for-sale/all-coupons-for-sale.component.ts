import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/models/Coupon';
import { CustomersService } from 'src/app/services/customers.service';

@Component({
  selector: 'app-all-coupons-for-sale',
  templateUrl: './all-coupons-for-sale.component.html',
  styleUrls: ['./all-coupons-for-sale.component.css']
})
export class AllCouponsForSaleComponent implements OnInit {
public allCoupons:Coupon[];
  constructor(private customerServ:CustomersService) { }

  ngOnInit() {
    this.getAllCoupons();
  }
  
  getAllCoupons()
  {
    this.customerServ.getAllCoupons().subscribe(coupons=>
      {this.allCoupons=coupons;
      },
      err=>{alert("Eror: "+err.error);
      });
  }
  purchaseCoupon(coupon:Coupon)
  {
    this.customerServ.purchaseCoupon(coupon).subscribe(data=>
     {alert("the coupon "+JSON.stringify(coupon)+"has purchase, "+coupon.price+"received");
    },err=>{
      alert("Eror: "+ err.error);
    }
    );
  }
}
