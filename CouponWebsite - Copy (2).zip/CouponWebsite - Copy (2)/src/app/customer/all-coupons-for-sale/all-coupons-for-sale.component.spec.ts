import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllCouponsForSaleComponent } from './all-coupons-for-sale.component';

describe('AllCouponsForSaleComponent', () => {
  let component: AllCouponsForSaleComponent;
  let fixture: ComponentFixture<AllCouponsForSaleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllCouponsForSaleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllCouponsForSaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
