import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './admin/main/main.component';

import { GetAllCustomersComponent } from './admin/get-all-customers/get-all-customers.component';
import { GetAllCompaniesComponent } from './admin/get-all-companies/get-all-companies.component';
import { GetCustomerComponent } from './admin/get-customer/get-customer.component';
import { GetCompanyComponent } from './admin/get-company/get-company.component';
import { CompayMainComponent } from './company/compay-main/compay-main.component';
import { AllCouponsComponent } from './company/all-coupons/all-coupons.component';
import { Coupon } from './models/Coupon';
import { GetCouponComponent } from './company/get-coupon/get-coupon.component';
import { CustomerComponent } from './customer/customer.component';
import { AllCouponsForSaleComponent } from './customer/all-coupons-for-sale/all-coupons-for-sale.component';
import { AllCustomerCouponsComponent } from './customer/all-customer-coupons/all-customer-coupons.component';
import { CustomerMainComponent } from './customer/customer-main/customer-main.component';
import { CompanyComponent } from './company/company.component';
import { AdminComponent } from './admin/admin.component';
import { LoginComponent } from './login/login.component';
import { OutcomesComponent } from './company/outcomes/outcomes.component';
import { IncomesComponent } from './admin/incomes/incomes.component';


const routes: Routes = [
  
  {path:'adminMain' ,component:MainComponent},
  {path:'All-Customers',component:GetAllCustomersComponent},
  {path:'all-companies',component:GetAllCompaniesComponent},
  {path:'customer/:id', component:GetCustomerComponent},
  {path:'company/:id',component:GetCompanyComponent},
  {path:'companyM',component:CompayMainComponent},
  {path:'allCoupons',component:AllCouponsComponent},
  {path:'coupon/:id',component:GetCouponComponent},
  {path:'customerHome', component:CustomerMainComponent},
  {path:'sale', component:AllCouponsForSaleComponent},
  {path:'customerCoupons', component:AllCustomerCouponsComponent},
  {path:'company',component:CompanyComponent},
  {path:'customer',component:CustomerComponent},
  {path:'admin',component:AdminComponent},
  {path:'login',component:LoginComponent},
  {path:'outcomes',component:OutcomesComponent},
  {path:'incomes',component:IncomesComponent}
  

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
