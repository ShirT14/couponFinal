import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/models/Customer';
import { AdminServicesService } from 'src/app/services/admin-services.service';
import { Observable, observable } from 'rxjs';



@Component({
  selector: 'app-get-all-customers',
  templateUrl: './get-all-customers.component.html',
  styleUrls: ['./get-all-customers.component.css']
})
export class GetAllCustomersComponent implements OnInit {
allCustomers: Customer[];
  constructor(private adminServ:AdminServicesService) { }

  ngOnInit() {
    
    this.getAllCustomers();
  }
  
  getAllCustomers()
  {
    this.adminServ.getAllCustomers().subscribe(customers=>{
      this.allCustomers=customers;
      console.log(this.allCustomers);
    },
      err=>{alert("Eror: "+err.error);
  });

}
deleteCustomer(id:number)
{
  
this.adminServ.deleteCustomer(id).subscribe(id =>{
  alert("customer id: "+ id+"deleted successfuly!");
}, err=>{alert("Eror: "+err.error);
});
}

}
