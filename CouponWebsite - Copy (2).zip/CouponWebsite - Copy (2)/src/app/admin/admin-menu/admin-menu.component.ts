import { Component, OnInit } from '@angular/core';
import { longStackSupport } from 'q';
import { AdminServicesService } from 'src/app/services/admin-services.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-menu',
  templateUrl: './admin-menu.component.html',
  styleUrls: ['./admin-menu.component.css']
})
export class AdminMenuComponent implements OnInit {

  constructor(private adminServ:AdminServicesService, private router:Router) { }

  ngOnInit() {
  }

  logout()
  {
this.adminServ.logout().subscribe(data=>
  {
    alert("you are logged out!");
    this.router.navigate(["/"]);
    
  },
    err=>{alert("Eror: "+err.error);

  });
  }
}

