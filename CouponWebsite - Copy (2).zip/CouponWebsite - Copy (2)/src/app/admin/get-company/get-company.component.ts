import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Company } from 'src/app/models/Company';
import { ActivatedRoute } from '@angular/router';
import { AdminServicesService } from 'src/app/services/admin-services.service';

@Component({
  selector: 'app-get-company',
  templateUrl: './get-company.component.html',
  styleUrls: ['./get-company.component.css']
})
export class GetCompanyComponent implements OnInit {
 public company:Company;
  clientForm: FormGroup;
  submitted=false;
  success=false;
  isAdd=false;
  sum:number=0;

  constructor(private activeRoute:ActivatedRoute, private adminServ:AdminServicesService, private formBuilder: FormBuilder) {
    this.clientForm=this.formBuilder.group({
      id:[{value:"",disabled: true },Validators.nullValidator],
      name:['',Validators.required],
      email:[{value:'',disabled:false},Validators.required],
      password:['',Validators.required]

     
    });
   }

  ngOnInit() {

    this.adminServ.getAllCompanies().subscribe(customers => {
      const id=this.activeRoute.snapshot.params.id; 
     if(id!=0)
     {
      this.company = customers.find(c=> c.id == id);
      this.totalIncomes(id);
     }
     else{
       this.isAdd=true;
       this.company=new Company();
     }
      
    }, err=>{alert("Eror: "+ err.error)
    
    
  });
  }
  addCompany()
  {
    this.adminServ.addCompany(this.company).subscribe(company=>{
      alert(JSON.stringify(this.company)+"added");
    },
     err=>{alert ("Eror: "+ err.error);
   console.log(err);  
    });
  }
  updateCompany()
  {
    this.adminServ.updatComapny(this.company).subscribe(company=>{
      alert(JSON.stringify(this.company)+"is up to date");
    },
     err=>{alert ("Eror: "+ err.error);
   console.log(err);  
    });
  }

  onSubmit()
  {
    this.submitted=true;
    if(this.clientForm.invalid)
    {
      return;
    }
    if(this.isAdd)
    {
      this.addCompany();
      this.success=true;
    }
    else{
      this.updateCompany();
      this.success=true;
    }
    this.success=true;

  
console.log(this.company);
    
  }
  onReset()
  {
    this.clientForm.reset();
  }
  totalIncomes(id:number){
    this.adminServ.companyIncome(id).subscribe(incomes=>{
      for(let i of incomes)
      {this.sum+=i.amount;
      }},
      err=>{alert("Could not load total income, Eror: "+err.error);
    });
  }
}
