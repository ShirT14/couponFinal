import { Component, OnInit } from '@angular/core';
import { Company } from 'src/app/models/Company';
import { AdminServicesService } from 'src/app/services/admin-services.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { observable } from 'rxjs';

@Component({
  selector: 'app-get-all-companies',
  templateUrl: './get-all-companies.component.html',
  styleUrls: ['./get-all-companies.component.css']
})
export class GetAllCompaniesComponent implements OnInit {
companies:Company[];
  constructor(private adminServ:AdminServicesService) { }

  ngOnInit() {
    this.getAllCompanies();
  }

  getAllCompanies()
  {
   this.adminServ.getAllCompanies().subscribe(companies=>{
     this.companies=companies;
    },
     err=>{alert("Eror: "+err.error);
   });
  }

  deleteCompany(id:number)
{
  alert(id);
this.adminServ.deleteCompany(id).subscribe(observable=>{
  alert("Company id: "+ id+"deleted successfuly!");
}, err=>{alert("Eror: "+err.error);
});
}
}

