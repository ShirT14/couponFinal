import { Component, OnInit } from '@angular/core';
import { Customer } from '../models/Customer';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AdminServicesService } from '../services/admin-services.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
 
  constructor() { 

   
  }
  
  ngOnInit() {
  }

}
