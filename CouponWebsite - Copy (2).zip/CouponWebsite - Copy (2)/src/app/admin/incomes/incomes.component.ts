import { Component, OnInit } from '@angular/core';
import { AdminServicesService } from 'src/app/services/admin-services.service';
import { Income } from 'src/app/models/Income';

@Component({
  selector: 'app-incomes',
  templateUrl: './incomes.component.html',
  styleUrls: ['./incomes.component.css']
})
export class IncomesComponent implements OnInit {
incomes:Income[];
sum:number=0;
  constructor(private adminServ:AdminServicesService) { }

  ngOnInit() {
    this.getIncomes();
  }

  getIncomes()
  {
    this.adminServ.incomes().subscribe(incomes=>{
      this.incomes=incomes;
      for(let i of this.incomes)
      {
            this.sum+=i.amount;
         
      }
    },err=>{alert("Eror: "+err.error);
    
    });
  }

}
