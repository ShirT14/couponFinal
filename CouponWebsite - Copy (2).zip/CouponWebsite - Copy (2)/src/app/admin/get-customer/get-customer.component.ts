import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/models/Customer';
import { ActivatedRoute } from '@angular/router';
import { AdminServicesService } from 'src/app/services/admin-services.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-get-customer',
  templateUrl: './get-customer.component.html',
  styleUrls: ['./get-customer.component.css']
})
export class GetCustomerComponent implements OnInit {
public customer:Customer;
public isAdd=false;
  clientForm: FormGroup;
  submitted=false;
  success=false;
  disabled=true;
  sum:number=0;


  

  constructor(private activeRoute:ActivatedRoute, private adminServ:AdminServicesService, private formBuilder: FormBuilder) {
    this.clientForm=this.formBuilder.group({
      id:[{value: '', disabled: true},Validators.required],
      first_name:['',Validators.required],
      last_name:['',Validators.required],
      email:[{value:'',disabled:false},Validators.required],
      password:['',Validators.required]
      });
}

  ngOnInit() {
    this.adminServ.getAllCustomers().subscribe(customers => {
      const id=this.activeRoute.snapshot.params.id; 
      if(id!=0)
      {
        this.customer = customers.find(c=> c.id == id);
        
        this.totalIncomes(id);
      }
      else{
        this.isAdd=true;
        this.disabled=false;
        this.customer=new  Customer();
      }
      
    }, err=>{alert("Eror: "+ err.error)
    
    
  });
  
  
  
  }
  onSubmit()
  {
    this.submitted=true;
    if(this.clientForm.invalid)
    {
      return;
    }
    if(this.isAdd)
    {
      this.addCustomer();
      this.success=true;
    }
    else{
      this.updateCustomer();
      this.success=true;
     
    }
    this.success=true;

  
console.log(this.customer);
    
  }
  updateCustomer()
  {
    this.adminServ.updateCustomer(this.customer).subscribe(customer=>{
      alert(JSON.stringify(this.customer)+"is up to date");
    },
     err=>{alert ("Eror: "+ err.error);
   console.log(err);  
    });
  }

  onReset()
  {
   
    
    this.clientForm.reset();
    
  }
  addCustomer()
  {
    this.adminServ.addCustomer(this.customer).subscribe(customer=>{
      alert(JSON.stringify(this.customer)+"added");
    },
     err=>{alert ("Eror: "+ err.error);
   console.log(err);  
    });
  }
  totalIncomes(id:number){
    this.adminServ.customerIncome(id).subscribe(incomes=>{
      for(let i of incomes)
      {this.sum+=i.amount;
      }},
      err=>{alert("Could not load total income, Eror: "+err.error);
    });
  }

}
