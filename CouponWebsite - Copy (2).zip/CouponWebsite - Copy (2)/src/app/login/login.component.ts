import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';

import { LoginService } from '../services/login.service';
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email: string;
  passwords: string;
  clientType: string;
  loginForm: FormGroup;
  isSubmited = false;


  constructor(private loginServ: LoginService, private fb: FormBuilder, private activeRout: Router) {

  }
  selectHandler(event: any) {
    this.clientType = event.target.value;
  }
  ngOnInit() {

    this.loginForm = new FormGroup({
      email: new FormControl('', Validators.required),
      passwords: new FormControl('', Validators.required),
      clientType: new FormControl('', Validators.required)
    });
  }

  submit() {


    this.login();
  }
  login() {

    this.loginServ.login(this.email, this.passwords, this.clientType).subscribe(data => {


      this.clearLogIn();
      this.isSubmited = true;
      if (this.clientType == "admin") {
        this.activeRout.navigate(['/adminMain']);

      }
      if (this.clientType == "company") {
        this.activeRout.navigate(['/companyM']);


      }
      if (this.clientType == "customer") {
        this.activeRout.navigate(['/customerHome']);


      }
    }


      , err => {
        alert("Worng email of password or client type! " + err.error
        );
      });
  }

  clearLogIn() {
    let login = document.getElementsByClassName("loginForm") as HTMLCollectionOf<HTMLElement>;
    login[0].style.display = 'none';
  }


}
