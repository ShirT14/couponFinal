import { Pipe, PipeTransform } from '@angular/core';
import { CompanyService } from './services/company.service';
import { FormsModule } from '@angular/forms';
import { stringify } from 'querystring';
import { get } from 'selenium-webdriver/http';
import { Observable } from 'rxjs';
import { promise } from 'protractor';
import { Promise, reject } from 'q';
import { PromiseType } from 'protractor/built/plugins';

@Pipe({
  name: "getCategory",
  pure: true

})
export class getCategoryPipe implements PipeTransform {
  
  constructor(private companyServ: CompanyService) {

  }
  transform(categoryId: number):string {
    switch (categoryId)
    {
      case 3:return "food";
      
      case 4: return "electricity";
      case 5: return "resturant";
      case 6: return "vacation";
      default: "no category found";
      
    }
    


    
  


  }



}