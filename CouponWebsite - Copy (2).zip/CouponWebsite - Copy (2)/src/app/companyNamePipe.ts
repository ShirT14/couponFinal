import { Pipe, PipeTransform } from '@angular/core';

import { CustomersService } from './services/customers.service';

@Pipe({
    name:"getCompanyName",
    pure:true
    
    })
    export class getCompanyPipe implements PipeTransform
    {
      constructor(private customerServ:CustomersService){}
      transform(companyId: number,ars:any) {
          
this.customerServ.getCompanyName(companyId).subscribe(companyName=>
      { return companyName;
    },
      err=>{alert("Eror: "+err.message);
    return "eror";}
      );
         
      }
    
    }