import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/models/Coupon';
import { CompanyService } from 'src/app/services/company.service';

import { FormGroup, FormBuilder, Validators, FormsModule, FormControl } from '@angular/forms';



@Component({
  selector: 'app-all-coupons',
  templateUrl: './all-coupons.component.html',
  styleUrls: ['./all-coupons.component.css']
})
export class AllCouponsComponent implements OnInit {
  public allCoupons: Coupon[];
  public categoryId: number;
  public maxPrice: number;
  public clientForm: FormGroup;


  constructor(private companyServ: CompanyService, private formBuilder: FormBuilder) {
    this.clientForm = new FormGroup({
      price:new FormControl ('', Validators.pattern["(0-9)"])
    });
  }

  ngOnInit() {

    this.getAllCoupons();
  }
  selectHandler(event: any) {
    this.categoryId = event.target.value;
    if(this.categoryId==0)
    {
      this.getAllCoupons();
    }
    else{
    this.getAllCouponsByCategory(this.categoryId);
    }
  }

  getAllCoupons() {
    this.companyServ.getAllCoupons().subscribe(coupons => {
      this.allCoupons = coupons;
      console.log(this.allCoupons);
    },
      err => {
        alert("Eror: " + err.message);
      });

  }
  getAllCouponsByMaxPrice() {
    this.companyServ.getAllCouponsByMaxPrice(this.maxPrice).subscribe(coupons => {
      this.allCoupons = coupons;

    },
      err => {
        alert("Eror: " + err.message);
      });

  }
  getAllCouponsByCategory(categoryId: number) {
    this.companyServ.getAllCouponsByCategory(categoryId).subscribe(coupons => {
      this.allCoupons = coupons;
      console.log(this.allCoupons);
    },
      err => {
        alert("Eror: " + err.message);
      });

  }
  deleteCoupon(id: number) {
    alert(id);
    this.companyServ.deleteCoupon(id).subscribe(id => {
      alert("company " + id + "deleted successfuly");
    }, err => {
      alert("Eror: " + err.message);
    });
  }


}


