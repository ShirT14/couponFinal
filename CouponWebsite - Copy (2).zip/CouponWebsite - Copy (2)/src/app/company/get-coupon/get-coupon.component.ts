import { Component, OnInit, NgModule, SystemJsNgModuleLoader } from '@angular/core';
import { Coupon } from 'src/app/models/Coupon';
import { FormGroup, FormBuilder, Validators, FormControl, NgModel } from '@angular/forms';
import { CompanyService } from 'src/app/services/company.service';
import { ActivatedRoute } from '@angular/router';

import { formatDate, DatePipe } from '@angular/common';
import { Company } from 'src/app/models/Company';




@Component({
  selector: 'app-get-coupon',
  templateUrl: './get-coupon.component.html',
  styleUrls: ['./get-coupon.component.css']
})
export class GetCouponComponent implements OnInit {
  public coupon: Coupon;
  clientForm:FormGroup;
  submitted = false;
  success = false;
  isAdd:boolean=false;
  company:Company;
  disabled:boolean;
  constructor(private activeRoute: ActivatedRoute, private companyServ: CompanyService,private datePipe:DatePipe ) {
  
  }
  selectHandler(event: any) {
    this.coupon.category = event.target.value;
  }
  ngOnInit() {
    
    this.getCompany();
    this.clientForm = new FormGroup({
      id: new FormControl({ value: '', disabled: true }, Validators.required),
      company: new FormControl({ value: '', disabled: true }),
      title: new FormControl({value:'',disabled:this.disabled}, Validators.required),
      description:new FormControl ('', Validators.required),
      startDate:new FormControl ('', Validators.required),
      endDate:new FormControl ('', Validators.required),
      amount:new FormControl ('', Validators.pattern["(0-9)"]),
      price:new FormControl ('', Validators.pattern["(0-9)"]),
      image:new FormControl ('', Validators.nullValidator),
      categoryId:new FormControl('', Validators.required)


    });



    this.companyServ.getAllCoupons().subscribe(coupons => {
      const id = this.activeRoute.snapshot.params.id;

      if (id != 0) {
        this.coupon = coupons.find(c => c.id == id);
        this.disabled=true;
        
     
      
     
    }
    else
    {
      this.isAdd=true;
    
        
        this.coupon=new Coupon();
      }
      

    }, err => {
      alert("Eror: " + err.error)

    });
   

  }
  transformDate(date:Date)
  {
    return this.datePipe.transform(date,"yyyy-MM-dd");
  }
  updateCoupon() {
    
    this.companyServ.updateCoupon(this.coupon).subscribe(coupon => {
      alert(JSON.stringify(this.coupon) + "is up to date");
    },
      err => {
        alert("Eror: " + err.error);
        console.log(err);
      });
  }
  onReset() {


    this.clientForm.reset();

  }
  addCoupon() {
   
    this.companyServ.addCoupon(this.coupon).subscribe(coupon => {
      alert(JSON.stringify(this.coupon) + "added");
    },
      err => {
        alert("Eror: " + err.error);
        console.log(err);
      });
  }
  onSubmit() {
    this.submitted = true;
    this.coupon.companyID=this.company.id;
    if (this.clientForm.invalid) {
      return;
    }
    if (this.isAdd) {
      this.addCoupon();
      this.success = true;
    }
    else {
      this.updateCoupon();
      this.success = true;
    }
    this.success = true;


    console.log(this.coupon);

  }
  getCompany()
  {
    this.companyServ.getCompany().subscribe(company=>{
      this.company=company;
      console.log(company);
    });
  }
}
