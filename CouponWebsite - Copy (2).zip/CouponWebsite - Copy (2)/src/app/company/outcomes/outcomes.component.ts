import { Component, OnInit } from '@angular/core';
import { CompanyService } from 'src/app/services/company.service';
import { Income } from 'src/app/models/Income';

@Component({
  selector: 'app-outcomes',
  templateUrl: './outcomes.component.html',
  styleUrls: ['./outcomes.component.css']
})
export class OutcomesComponent implements OnInit {
  public outcomes:Income[];
  public companyName:string;
  sum:number=0;
  constructor(private companyServ:CompanyService) { }

  ngOnInit() {
    this.getOutcomes();
    this.companyServ.getCompany().subscribe(company=>
      {
        this.companyName=company.name;
       
      })
  }
  getOutcomes(){
    this.companyServ.incomes().subscribe(incomes=>{
      this.outcomes=incomes;
      for(let o of this.outcomes)
      {
         this.sum+=o.amount;
      }
    },err=>{alert("Eror: "+err.error);
    })

  }

}
