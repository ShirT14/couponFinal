import { Component, OnInit } from '@angular/core';
import { CompanyService } from 'src/app/services/company.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-company-menu',
  templateUrl: './company-menu.component.html',
  styleUrls: ['./company-menu.component.css']
})
export class CompanyMenuComponent implements OnInit {

  constructor(private companyServ:CompanyService,private route:Router) { }

  ngOnInit() {
  }
  logout()
  {
this.companyServ.logout().subscribe(data=>{
  alert("you are logged out");
  this.route.navigate(["/"]);
  
},
  err=>{alert("Eror: "+err.massage);
});
  }

}
