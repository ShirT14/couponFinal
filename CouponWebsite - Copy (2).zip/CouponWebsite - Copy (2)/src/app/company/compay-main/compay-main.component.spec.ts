import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompayMainComponent } from './compay-main.component';

describe('CompayMainComponent', () => {
  let component: CompayMainComponent;
  let fixture: ComponentFixture<CompayMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompayMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompayMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
