import { Component, OnInit } from '@angular/core';
import { Company } from 'src/app/models/Company';
import { CompanyService } from 'src/app/services/company.service';
import { GetCompanyComponent } from 'src/app/admin/get-company/get-company.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-compay-main',
  templateUrl: './compay-main.component.html',
  styleUrls: ['./compay-main.component.css']
})
export class CompayMainComponent implements OnInit {
public company:Company;
public companyName:string;
  constructor(private companyServ:CompanyService, private route: Router) { }

  ngOnInit() {
    this.getCompany();

    
  }

  getCompany()
  {
  this.companyServ.getCompany().subscribe(company=>
    {this.company=company;
      this.companyName=this.company.name;
    },
    err=>{alert("Eror: "+err.error);
  });
 
}
}