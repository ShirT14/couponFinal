export class Income{
    constructor(
        public id?:number,
        public name?:string,
        public date?:Date,
        public description?:string,
        public amount?:number,
        public clientId?:number

    ){}
}