import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AdminComponent } from './admin/admin.component';
import { AdminMenuComponent } from './admin/admin-menu/admin-menu.component';
import { MainComponent } from './admin/main/main.component';

import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule }   from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { from } from 'rxjs';

import { GetAllCustomersComponent } from './admin/get-all-customers/get-all-customers.component';
import { GetAllCompaniesComponent } from './admin/get-all-companies/get-all-companies.component';
import { GetCustomerComponent } from './admin/get-customer/get-customer.component';
import { GetCompanyComponent } from './admin/get-company/get-company.component';
import { CompanyComponent } from './company/company.component';
import { CompanyMenuComponent } from './company/company-menu/company-menu.component';
import { CompayMainComponent } from './company/compay-main/compay-main.component';
import { AllCouponsComponent } from './company/all-coupons/all-coupons.component';
import { ThumbnailComponent } from './thumbnail/thumbnail.component';
import { GetCouponComponent } from './company/get-coupon/get-coupon.component';

import { getCategoryPipe } from './categoryPipe';
import { AllCustomerCouponsComponent } from './customer/all-customer-coupons/all-customer-coupons.component';
import { AllCouponsForSaleComponent } from './customer/all-coupons-for-sale/all-coupons-for-sale.component';
import { CustomerMainComponent } from './customer/customer-main/customer-main.component';
import { CustomerMenuComponent } from './customer/customer-menu/customer-menu.component';
import { CustomerComponent } from './customer/customer.component';
import { getCompanyPipe } from './companyNamePipe';
import { getCustomerCategoryPipe } from './CustomerCategoryPipe';
import { LoginComponent } from './login/login.component';
import { DatePipe } from '@angular/common';
import { OutcomesComponent } from './company/outcomes/outcomes.component';
import { IncomesComponent } from './admin/incomes/incomes.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    AdminComponent,
    AdminMenuComponent,
    MainComponent,
    getCategoryPipe,
    getCompanyPipe,
    getCustomerCategoryPipe,
    
   
    
    GetAllCustomersComponent,
    
    GetAllCompaniesComponent,
    
    GetCustomerComponent,
    
    GetCompanyComponent,
    
    CompanyComponent,
    
    CompanyMenuComponent,
    
    CompayMainComponent,
    
    AllCouponsComponent,
   
    
    ThumbnailComponent,
    
    GetCouponComponent,
    
    AllCustomerCouponsComponent,
    
    AllCouponsForSaleComponent,
    
    CustomerMainComponent,
    
    CustomerMenuComponent,
    
    CustomerComponent,
    
    LoginComponent,
    
    OutcomesComponent,
    
    IncomesComponent,
    
    

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    
    ReactiveFormsModule,
   
    
   
  
  ],
  providers: [
    DatePipe,
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { transports: ['websocket']}

